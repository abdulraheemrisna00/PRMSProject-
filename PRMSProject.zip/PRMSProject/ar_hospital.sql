-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2025 at 12:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ar_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctordetails`
--

CREATE TABLE `doctordetails` (
  `ID` int(110) NOT NULL,
  `Full_Name` varchar(250) NOT NULL,
  `Age` int(10) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Phone_No` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctordetails`
--

INSERT INTO `doctordetails` (`ID`, `Full_Name`, `Age`, `Gender`, `Address`, `Phone_No`) VALUES
(1, 'Harini Kumar', 37, 'Female', '234,Colombo Street', '0777555586'),
(2, 'Vijay Sedhupathy', 55, 'Male', '45,Kandy Road-03', '0786576589'),
(3, 'Kumara Thunka', 55, 'Male', '76,PM Road', '0778769897'),
(4, 'Mahesh Retty', 57, 'Male', '123/3, Town Hall Road', '0766666777'),
(6, 'Harini Kumar', 32, 'Female', '234,Colombo Street', '0777656786'),
(7, 'Risna Abdul Raheem', 45, 'Female', 'eeeeee34eee', '0765434597');

-- --------------------------------------------------------

--
-- Table structure for table `inpatientdetails`
--

CREATE TABLE `inpatientdetails` (
  `IP_No` int(250) NOT NULL,
  `Full_Name` varchar(127) NOT NULL,
  `Age` int(15) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Phone_No` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `inpatientdetails`
--

INSERT INTO `inpatientdetails` (`IP_No`, `Full_Name`, `Age`, `Gender`, `Address`, `Phone_No`) VALUES
(1, 'Adbul Raheem Risna', 53, 'Female', '225/e,KKP Road,Kalmunai', '0774476776'),
(2, 'Kumara Devi ', 65, 'Female', '34,GP Road', '0763434545'),
(3, 'Kumara Vartheshi', 50, 'Female', '231/3, TRP Road', '0765432345'),
(4, 'Anuratha Krishna Kumar', 67, 'Female', '234,KKP Road', '0765435678'),
(6, 'Anuratha Krishna Kumar', 46, 'Female', '234,KKP Road', '0765435678');

-- --------------------------------------------------------

--
-- Table structure for table `inpatientmedicaldetails`
--

CREATE TABLE `inpatientmedicaldetails` (
  `IP_No` int(15) NOT NULL,
  `Full_Name` varchar(250) NOT NULL,
  `Doctor` varchar(250) NOT NULL,
  `Admission_Date` date NOT NULL,
  `Discharge_Date` date NOT NULL,
  `Health_Statement` varchar(500) NOT NULL,
  `Fees` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `inpatientmedicaldetails`
--

INSERT INTO `inpatientmedicaldetails` (`IP_No`, `Full_Name`, `Doctor`, `Admission_Date`, `Discharge_Date`, `Health_Statement`, `Fees`) VALUES
(1, 'Adbul Raheem Risna', 'Radha Unnikrishna', '2025-04-02', '2025-04-15', 'Now better. But regular checkup is must', 1400),
(2, 'Vijaya Varthane', 'Vikram Aathidya', '2024-01-15', '2024-02-25', 'Now she is fine', 1000),
(3, 'Kumara Varthesi', 'Vikram Aathidya', '2024-07-13', '2024-07-18', 'Now she is fine', 980),
(4, 'Kumara Varthesi', 'Vikram Aathidya', '2024-09-03', '2024-10-28', 'Now she is fine', 1500),
(5, 'Pavithra Lakshmy Puvanathan', 'Radha Unnikrishna', '2025-03-22', '2025-04-05', 'Now better. But regular checkup is must', 780);

-- --------------------------------------------------------

--
-- Table structure for table `outpatientdetails`
--

CREATE TABLE `outpatientdetails` (
  `OP_NO` int(15) NOT NULL,
  `Full_Name` varchar(250) NOT NULL,
  `Age` int(10) NOT NULL,
  `Gender` varchar(15) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Phone_No` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `outpatientdetails`
--

INSERT INTO `outpatientdetails` (`OP_NO`, `Full_Name`, `Age`, `Gender`, `Address`, `Phone_No`) VALUES
(1, 'Mohammed Ismail', 35, 'Male', '123/e, TTR Road', '0768956547'),
(2, 'Jayam Kumar', 44, 'Male', '123, KKP Road', '0786578765'),
(4, 'Fathima Iska', 25, 'Female', '133/e, KKP Road', '0768556547');

-- --------------------------------------------------------

--
-- Table structure for table `outpatientmedicaldetails`
--

CREATE TABLE `outpatientmedicaldetails` (
  `OP_No` int(11) NOT NULL,
  `Full_Name` varchar(250) NOT NULL,
  `Doctor` varchar(250) NOT NULL,
  `Health_Statement` varchar(500) NOT NULL,
  `Date` date NOT NULL,
  `Fee` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `outpatientmedicaldetails`
--

INSERT INTO `outpatientmedicaldetails` (`OP_No`, `Full_Name`, `Doctor`, `Health_Statement`, `Date`, `Fee`) VALUES
(1, 'Mohammed Ismail', 'Ravi Kumar', 'Need bed rest', '2025-02-13', 750),
(2, 'Jayam Kumar', 'Vijay Anteny', 'Perfectly all right', '2025-04-17', 1500),
(4, 'Fathima Iska', 'Aaaaaa', 'vvhjhghk', '2025-03-12', 233);

-- --------------------------------------------------------

--
-- Table structure for table `registration_page`
--

CREATE TABLE `registration_page` (
  `First_Name` varchar(250) NOT NULL,
  `Last_Name` varchar(250) NOT NULL,
  `Gender` varchar(250) NOT NULL,
  `Age` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `Pin_Code` varchar(11) NOT NULL,
  `District` varchar(250) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Email` varchar(450) NOT NULL,
  `Phone_No` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration_page`
--

INSERT INTO `registration_page` (`First_Name`, `Last_Name`, `Gender`, `Age`, `DOB`, `Pin_Code`, `District`, `Address`, `Email`, `Phone_No`) VALUES
('Abdul Raheem', 'Risna', 'Female', 23, '2002-12-13', '330', ' Ampara', '123,Aliyar Road', 'dfgergrgtr', '23435'),
('Mohammed', 'Fathima Aakila', 'Female', 24, '2001-02-22', '550', 'Anuradhapura', '345/A,GH Road', 'hghjguyuil', '771234354'),
('Abdul Raheem', 'Risna', 'Female', 23, '2002-12-13', '550', ' Ampara', '234,KKP Road', 'risna_09@gmail.com', '0765435655'),
('Abdul Raheem', 'Risna', 'Female', 23, '2002-12-13', '550', ' Ampara', '345,STR Road', 'sdgt_nfkjg@gmail.com', '0787654565'),
('Kumaradunka', 'Veeravardana', 'Male', 40, '2025-05-12', '00550', 'Polonnaruwa', '234,Post Office Road', 'kumara67@gmail.com', '0775649876'),
('Rfgh', 'Edfhgyh', 'Female', 33, '2002-12-24', '00550', 'Badulla', '345/e,GP Road', 'rgpf@gmail.com', '0768875434'),
('Fhghjhm', 'Cbnbm', 'Female', 34, '2025-05-13', '00330', 'Colombo', '23/E, Townhall Road', 'dgrtgh23@gmail.com', '0765434344'),
('Afghh', 'Sdtd Sgghj', 'Male', 40, '2025-03-23', '00110', 'Colombo', 'gyugyu0/78ghj', 'guygug768@gmail.com', '0765476543'),
('Ahgjgj', 'Svhvh', 'Female', 45, '2002-12-13', '00550', 'Badulla', 'jhjjkhkhkj', 'hjhjk56@gmail.com', '0754567865'),
('Zhghj', 'Ajhkjhjk', 'Male', 65, '2002-12-13', '00550', 'Badulla', 'hjguhgiu76', 'huygjh@gmail.com', '0765434567'),
('Abdu Raheem', 'Rikas', 'Male', 15, '2010-04-26', '00110', 'Batticaloa', '234E/3, Townhall Road, Kalmunaikkudy-13', 'Kingrikas@gmail.com', '0775645645');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctordetails`
--
ALTER TABLE `doctordetails`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `inpatientdetails`
--
ALTER TABLE `inpatientdetails`
  ADD PRIMARY KEY (`IP_No`);

--
-- Indexes for table `inpatientmedicaldetails`
--
ALTER TABLE `inpatientmedicaldetails`
  ADD PRIMARY KEY (`IP_No`);

--
-- Indexes for table `outpatientdetails`
--
ALTER TABLE `outpatientdetails`
  ADD PRIMARY KEY (`OP_NO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
